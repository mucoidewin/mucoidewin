
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [sortBy, setSortBy] = useState('Mới nhất');

  const categories = ['Tất cả', 'Truyền thống', 'Thời trang', 'Thêu hoa', 'Trang trí'];
  const sortOptions = ['Mới nhất', 'Giá thấp đến cao', 'Giá cao đến thấp', 'Phổ biến nhất'];

  const products = [
    {
      id: 1,
      name: "Mũ Cối Truyền Thống Hà Nội",
      price: "299,000",
      originalPrice: "399,000",
      category: "Truyền thống",
      image: "https://readdy.ai/api/search-image?query=Traditional%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20from%20Hanoi%2C%20classic%20style%20made%20from%20palm%20leaves%2C%20authentic%20craftsmanship%2C%20white%20clean%20background%2C%20product%20photography%20style%2C%20high%20quality%20detailed%20texture%2C%20natural%20lighting&width=300&height=300&seq=prod1&orientation=squarish",
      badge: "Sale",
      rating: 4.8,
      sold: 156
    },
    {
      id: 2,
      name: "Mũ Cối Cao Cấp Huế",
      price: "450,000",
      category: "Thời trang",
      image: "https://readdy.ai/api/search-image?query=Premium%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20from%20Hue%20with%20fine%20weaving%2C%20luxury%20craftsmanship%2C%20elegant%20design%2C%20white%20clean%20background%2C%20professional%20product%20photography%2C%20detailed%20texture&width=300&height=300&seq=prod2&orientation=squarish",
      badge: "Mới",
      rating: 4.9,
      sold: 89
    },
    {
      id: 3,
      name: "Mũ Cối Thêu Hoa Sen",
      price: "350,000",
      category: "Thêu hoa",
      image: "https://readdy.ai/api/search-image?query=Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20with%20beautiful%20lotus%20flower%20embroidery%2C%20traditional%20handicraft%2C%20palm%20leaves%20with%20pink%20lotus%20designs%2C%20white%20clean%20background%2C%20artistic%20photography%2C%20detailed%20needlework&width=300&height=300&seq=prod3&orientation=squarish",
      badge: "Hot",
      rating: 4.7,
      sold: 203
    },
    {
      id: 4,
      name: "Mũ Cối Mini Trang Trí",
      price: "199,000",
      category: "Trang trí",
      image: "https://readdy.ai/api/search-image?query=Small%20decorative%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%2C%20miniature%20size%20for%20home%20decoration%2C%20traditional%20weaving%2C%20white%20clean%20background%2C%20cute%20presentation%2C%20detailed%20craftsmanship%2C%20souvenir%20style&width=300&height=300&seq=prod4&orientation=squarish",
      rating: 4.6,
      sold: 67
    },
    {
      id: 5,
      name: "Mũ Cối Thêu Rồng Vàng",
      price: "520,000",
      category: "Thêu hoa",
      image: "https://readdy.ai/api/search-image?query=Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20with%20golden%20dragon%20embroidery%2C%20traditional%20Vietnamese%20dragon%20motif%2C%20luxury%20handicraft%2C%20palm%20leaves%20with%20gold%20thread%20embroidery%2C%20white%20clean%20background%2C%20premium%20quality&width=300&height=300&seq=prod5&orientation=squarish",
      badge: "Cao cấp",
      rating: 5.0,
      sold: 34
    },
    {
      id: 6,
      name: "Mũ Cối Dân Gian Miền Trung",
      price: "275,000",
      category: "Truyền thống",
      image: "https://readdy.ai/api/search-image?query=Traditional%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20from%20Central%20Vietnam%2C%20folk%20style%20with%20authentic%20weaving%20patterns%2C%20natural%20palm%20leaves%2C%20white%20clean%20background%2C%20traditional%20craftsmanship%2C%20cultural%20heritage&width=300&height=300&seq=prod6&orientation=squarish",
      rating: 4.5,
      sold: 128
    },
    {
      id: 7,
      name: "Mũ Cối Thời Trang Hiện Đại",
      price: "380,000",
      category: "Thời trang",
      image: "https://readdy.ai/api/search-image?query=Modern%20fashion%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%2C%20contemporary%20design%2C%20stylish%20interpretation%20of%20traditional%20hat%2C%20clean%20white%20background%2C%20fashionable%20presentation%2C%20innovative%20craftsmanship&width=300&height=300&seq=prod7&orientation=squarish",
      badge: "Trending",
      rating: 4.4,
      sold: 92
    },
    {
      id: 8,
      name: "Mũ Cối Thêu Hoa Đào",
      price: "325,000",
      category: "Thêu hoa",
      image: "https://readdy.ai/api/search-image?query=Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20with%20peach%20blossom%20embroidery%2C%20traditional%20spring%20flower%20motif%2C%20pink%20peach%20flowers%20embroidered%20on%20palm%20leaves%2C%20white%20clean%20background%2C%20delicate%20needlework&width=300&height=300&seq=prod8&orientation=squarish",
      rating: 4.6,
      sold: 145
    }
  ];

  const filteredProducts = selectedCategory === 'Tất cả' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <Link href="/" className="text-2xl font-pacifico text-emerald-600">
                logo
              </Link>
              <nav className="hidden md:flex space-x-6">
                <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors">Trang chủ</Link>
                <Link href="/products" className="text-emerald-600 font-medium">Sản phẩm</Link>
                <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors">Về chúng tôi</Link>
                <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors">Liên hệ</Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <i className="ri-search-line w-5 h-5 flex items-center justify-center"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <i className="ri-heart-line w-5 h-5 flex items-center justify-center"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
                <i className="ri-shopping-cart-line w-5 h-5 flex items-center justify-center"></i>
                <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">2</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-emerald-600">Trang chủ</Link>
            <i className="ri-arrow-right-s-line w-4 h-4 flex items-center justify-center"></i>
            <span className="text-gray-900">Sản phẩm</span>
          </div>
        </nav>

        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Tất Cả Sản Phẩm</h1>
          <p className="text-gray-600">Khám phá bộ sưu tập mũ cối truyền thống Việt Nam của chúng tôi</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-4">Danh Mục</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`block w-full text-left px-3 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      selectedCategory === category
                        ? 'bg-emerald-100 text-emerald-700 font-medium'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div className="bg-white rounded-lg p-6 shadow-sm mt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Khoảng Giá</h3>
              <div className="space-y-2">
                {[
                  'Dưới 200,000đ',
                  '200,000đ - 300,000đ',
                  '300,000đ - 400,000đ',
                  'Trên 400,000đ'
                ].map((range) => (
                  <label key={range} className="flex items-center cursor-pointer">
                    <input type="checkbox" className="mr-3 text-emerald-600 rounded" />
                    <span className="text-gray-700">{range}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Rating Filter */}
            <div className="bg-white rounded-lg p-6 shadow-sm mt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Đánh Giá</h3>
              <div className="space-y-2">
                {[5, 4, 3].map((rating) => (
                  <label key={rating} className="flex items-center cursor-pointer">
                    <input type="checkbox" className="mr-3 text-emerald-600 rounded" />
                    <div className="flex items-center">
                      <div className="flex mr-2">
                        {[...Array(rating)].map((_, i) => (
                          <i key={i} className="ri-star-fill w-4 h-4 flex items-center justify-center text-yellow-400"></i>
                        ))}
                        {[...Array(5 - rating)].map((_, i) => (
                          <i key={i} className="ri-star-line w-4 h-4 flex items-center justify-center text-gray-300"></i>
                        ))}
                      </div>
                      <span className="text-gray-700">& lên</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="lg:col-span-3">
            {/* Sort and Results */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
              <div className="text-gray-600 mb-4 sm:mb-0">
                Hiển thị {filteredProducts.length} sản phẩm
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600">Sắp xếp:</span>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  {sortOptions.map((option) => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <Image 
                      src={product.image} 
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-48 object-cover object-top"
                    />
                    {product.badge && (
                      <span className={`absolute top-3 left-3 px-2 py-1 rounded-full text-xs font-semibold ${
                        product.badge === 'Sale' ? 'bg-red-500 text-white' :
                        product.badge === 'Mới' ? 'bg-blue-500 text-white' :
                        product.badge === 'Hot' ? 'bg-orange-500 text-white' :
                        product.badge === 'Cao cấp' ? 'bg-purple-500 text-white' :
                        product.badge === 'Trending' ? 'bg-green-500 text-white' :
                        'bg-gray-500 text-white'
                      }`}>
                        {product.badge}
                      </span>
                    )}
                    <button className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors">
                      <i className="ri-heart-line w-4 h-4 flex items-center justify-center text-gray-600"></i>
                    </button>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-gray-900 mb-2 line-clamp-2">{product.name}</h3>
                    <div className="flex items-center mb-2">
                      <div className="flex mr-2">
                        {[...Array(5)].map((_, i) => (
                          <i 
                            key={i} 
                            className={`w-4 h-4 flex items-center justify-center ${
                              i < Math.floor(product.rating) 
                                ? 'ri-star-fill text-yellow-400' 
                                : 'ri-star-line text-gray-300'
                            }`}
                          ></i>
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">({product.sold})</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-emerald-600">{product.price}đ</span>
                        {product.originalPrice && (
                          <span className="text-sm text-gray-500 line-through">{product.originalPrice}đ</span>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer">
                        Thêm giỏ hàng
                      </button>
                      <button className="p-2 border border-gray-300 hover:border-emerald-600 rounded-lg transition-colors">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center text-gray-600 hover:text-emerald-600"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-center mt-12">
              <div className="flex items-center space-x-2">
                <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                  <i className="ri-arrow-left-line w-4 h-4 flex items-center justify-center"></i>
                </button>
                {[1, 2, 3].map((page) => (
                  <button
                    key={page}
                    className={`w-10 h-10 rounded-lg font-medium transition-colors cursor-pointer ${
                      page === 1
                        ? 'bg-emerald-600 text-white'
                        : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                  <i className="ri-arrow-right-line w-4 h-4 flex items-center justify-center"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
