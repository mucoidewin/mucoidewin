
'use client';

import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  const featuredProducts = [
    {
      id: 1,
      name: "Mũ Cối Truyền Thống",
      price: "299,000",
      originalPrice: "399,000",
      image: "https://readdy.ai/api/search-image?query=Traditional%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20made%20from%20palm%20leaves%2C%20beautiful%20craftsmanship%2C%20white%20clean%20background%2C%20product%20photography%20style%2C%20high%20quality%20detailed%20texture%2C%20natural%20lighting%2C%20elegant%20presentation%2C%20minimalist%20setting&width=400&height=400&seq=hat1&orientation=squarish",
      badge: "Bán chạy"
    },
    {
      id: 2,
      name: "Mũ Cối Cao Cấp",
      price: "450,000",
      image: "https://readdy.ai/api/search-image?query=Premium%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20with%20intricate%20patterns%2C%20fine%20woven%20palm%20leaves%2C%20luxury%20craftsmanship%2C%20white%20clean%20background%2C%20product%20photography%2C%20professional%20lighting%2C%20elegant%20display%2C%20detailed%20texture&width=400&height=400&seq=hat2&orientation=squarish",
      badge: "Mới"
    },
    {
      id: 3,
      name: "Mũ Cối Thêu Hoa",
      price: "350,000",
      image: "https://readdy.ai/api/search-image?query=Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%20with%20beautiful%20floral%20embroidery%20patterns%2C%20traditional%20handicraft%2C%20palm%20leaves%20with%20colorful%20flower%20designs%2C%20white%20clean%20background%2C%20artistic%20photography%2C%20detailed%20needlework&width=400&height=400&seq=hat3&orientation=squarish",
      badge: "Độc đáo"
    },
    {
      id: 4,
      name: "Mũ Cối Mini Trang Trí",
      price: "199,000",
      image: "https://readdy.ai/api/search-image?query=Small%20decorative%20Vietnamese%20conical%20hat%20n%C3%B3n%20l%C3%A1%2C%20miniature%20size%2C%20perfect%20for%20home%20decoration%20or%20souvenirs%2C%20traditional%20weaving%2C%20white%20clean%20background%2C%20cute%20and%20charming%20presentation%2C%20detailed%20craftsmanship&width=400&height=400&seq=hat4&orientation=squarish"
    }
  ];

  const categories = [
    { name: "Mũ Cối Truyền Thống", count: 12, icon: "ri-history-line" },
    { name: "Mũ Cối Thời Trang", count: 8, icon: "ri-shirt-line" },
    { name: "Mũ Cối Thêu Hoa", count: 15, icon: "ri-flower-line" },
    { name: "Mũ Cối Trang Trí", count: 6, icon: "ri-home-line" }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <Link href="/" className="text-2xl font-pacifico text-emerald-600">
                logo
              </Link>
              <nav className="hidden md:flex space-x-6">
                <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors">Trang chủ</Link>
                <Link href="/products" className="text-gray-700 hover:text-emerald-600 transition-colors">Sản phẩm</Link>
                <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors">Về chúng tôi</Link>
                <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors">Liên hệ</Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <i className="ri-search-line w-5 h-5 flex items-center justify-center"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <i className="ri-heart-line w-5 h-5 flex items-center justify-center"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
                <i className="ri-shopping-cart-line w-5 h-5 flex items-center justify-center"></i>
                <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">2</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section 
        className="relative h-96 md:h-[500px] bg-cover bg-center bg-no-repeat flex items-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('https://readdy.ai/api/search-image?query=Vietnamese%20woman%20wearing%20traditional%20conical%20hat%20n%C3%B3n%20l%C3%A1%20in%20rice%20field%2C%20golden%20sunlight%2C%20peaceful%20countryside%20landscape%2C%20traditional%20clothing%20%C3%A1o%20d%C3%A0i%2C%20cultural%20heritage%2C%20beautiful%20scenery%20with%20green%20rice%20paddies%2C%20warm%20lighting%2C%20authentic%20Vietnam%20culture&width=1200&height=500&seq=hero1&orientation=landscape')`
        }}
      >
        <div className="container mx-auto px-4 w-full">
          <div className="max-w-2xl text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Mũ Cối Truyền Thống
            </h1>
            <p className="text-xl mb-8 text-gray-100">
              Khám phá vẻ đẹp của nón lá Việt Nam với bộ sưu tập mũ cối thủ công tinh xảo, 
              mang đậm bản sắc văn hóa dân tộc
            </p>
            <div className="flex space-x-4">
              <Link 
                href="/products" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-full font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Mua ngay
              </Link>
              <button className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-3 rounded-full font-semibold transition-colors whitespace-nowrap cursor-pointer">
                Tìm hiểu thêm
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Danh Mục Sản Phẩm</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Chúng tôi có nhiều loại mũ cối khác nhau, từ truyền thống đến hiện đại
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <div key={index} className="bg-white rounded-lg p-6 text-center hover:shadow-lg transition-shadow cursor-pointer">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${category.icon} w-8 h-8 flex items-center justify-center text-emerald-600`}></i>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-gray-500 text-sm">{category.count} sản phẩm</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Sản Phẩm Nổi Bật</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Những chiếc mũ cối được làm thủ công tỉ mỉ, chất lượng cao nhất
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <Image 
                    src={product.image} 
                    alt={product.name}
                    width={400}
                    height={400}
                    className="w-full h-64 object-cover object-top"
                  />
                  {product.badge && (
                    <span className="absolute top-3 left-3 bg-emerald-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                      {product.badge}
                    </span>
                  )}
                  <button className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors">
                    <i className="ri-heart-line w-4 h-4 flex items-center justify-center text-gray-600"></i>
                  </button>
                </div>
                <div className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-emerald-600">{product.price}đ</span>
                      {product.originalPrice && (
                        <span className="text-sm text-gray-500 line-through">{product.originalPrice}đ</span>
                      )}
                    </div>
                  </div>
                  <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer">
                    Thêm vào giỏ
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link 
              href="/products" 
              className="inline-block bg-white border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-600 hover:text-white px-8 py-3 rounded-full font-semibold transition-colors whitespace-nowrap cursor-pointer"
            >
              Xem tất cả sản phẩm
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Về Nghệ Thuật Làm Mũ Cối</h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Mũ cối (nón lá) là biểu tượng văn hóa độc đáo của Việt Nam, được làm hoàn toàn thủ công 
                từ lá cây cọ non. Mỗi chiếc mũ cối đều mang trong mình tâm huyết và tài nghệ của người thợ thủ công.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Chúng tôi cam kết mang đến những sản phẩm chất lượng cao nhất, giữ gìn và phát huy 
                giá trị truyền thống của nghề làm mũ cối Việt Nam.
              </p>
              <div className="flex space-x-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600 mb-2">15+</div>
                  <div className="text-gray-600 text-sm">Năm kinh nghiệm</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600 mb-2">500+</div>
                  <div className="text-gray-600 text-sm">Sản phẩm bán ra</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600 mb-2">100%</div>
                  <div className="text-gray-600 text-sm">Thủ công</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <Image 
                src="https://readdy.ai/api/search-image?query=Vietnamese%20artisan%20craftsperson%20making%20traditional%20conical%20hat%20n%C3%B3n%20l%C3%A1%2C%20detailed%20handwork%20process%2C%20weaving%20palm%20leaves%2C%20traditional%20workshop%2C%20skilled%20hands%20creating%20beautiful%20handicraft%2C%20authentic%20cultural%20scene%2C%20natural%20lighting&width=600&height=400&seq=craft1&orientation=landscape"
                alt="Nghệ nhân làm mũ cối"
                width={600}
                height={400}
                className="rounded-lg shadow-lg object-cover object-top"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Khách Hàng Nói Gì</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Những chia sẻ chân thật từ khách hàng đã mua sản phẩm
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Nguyễn Thị Lan",
                role: "Khách hàng thân thiết",
                content: "Mũ cối rất đẹp và chất lượng. Tôi đã mua làm quà tặng cho bạn nước ngoài và họ rất thích.",
                rating: 5
              },
              {
                name: "Trần Văn Minh",
                role: "Người sưu tầm",
                content: "Sản phẩm đúng như mô tả, đóng gói cẩn thận. Chất lượng mũ cối rất tốt, đáng đồng tiền bát gạo.",
                rating: 5
              },
              {
                name: "Lê Thị Hoa",
                role: "Khách hàng mới",
                content: "Giao hàng nhanh, sản phẩm đẹp. Tôi sẽ giới thiệu cho bạn bè và sẽ mua thêm trong tương lai.",
                rating: 5
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <i key={i} className="ri-star-fill w-5 h-5 flex items-center justify-center text-yellow-400"></i>
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">"{testimonial.content}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="text-2xl font-pacifico text-emerald-400 mb-4">logo</div>
              <p className="text-gray-300 mb-4">
                Chuyên cung cấp mũ cối truyền thống Việt Nam chất lượng cao, 
                được làm thủ công bởi các nghệ nhân tài ba.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                  <i className="ri-facebook-fill w-4 h-4 flex items-center justify-center"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                  <i className="ri-instagram-fill w-4 h-4 flex items-center justify-center"></i>
                </a>
                <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                  <i className="ri-youtube-fill w-4 h-4 flex items-center justify-center"></i>
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Sản Phẩm</h3>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Mũ Cối Truyền Thống</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Mũ Cối Thời Trang</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Mũ Cối Thêu Hoa</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Mũ Cối Trang Trí</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Hỗ Trợ</h3>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Hướng dẫn đặt hàng</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Chính sách đổi trả</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Vận chuyển</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Liên Hệ</h3>
              <ul className="space-y-2 text-gray-300">
                <li className="flex items-center">
                  <i className="ri-phone-line w-4 h-4 flex items-center justify-center mr-2"></i>
                  0123 456 789
                </li>
                <li className="flex items-center">
                  <i className="ri-mail-line w-4 h-4 flex items-center justify-center mr-2"></i>
                  info@mucoi.vn
                </li>
                <li className="flex items-center">
                  <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-2"></i>
                  Hà Nội, Việt Nam
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-300">
            <p>&copy; 2024 Mũ Cối Việt Nam. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
